package com.One2One;
import com.One2One.entity.*;
import com.One2One.dao.*;



public class App {

    public static void main( String[] args ) {
    	 Instructor instructor = new Instructor();
    	 instructor.setFirstname("Aftab");
    	 instructor.setLastname("P");
    	 
    	 
    	 InstructorDao instructorDao = new InstructorDao();
         instructorDao.saveInstructor(instructor);
         
         InstructorDetail instructorDetail = new InstructorDetail();
         instructorDetail.setYoutubeChannel("shivarock.youtube");
         instructorDetail.setHobby("Playing Football");
         
         instructor.setInstructordetail(instructorDetail);
    }
}